__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/d0cfb5d929b9d6a8.js",
  "static/chunks/turbopack-06b915e650bd332d.js"
])
