__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/d0cfb5d929b9d6a8.js",
  "static/chunks/turbopack-aec69323c865d5aa.js"
])
