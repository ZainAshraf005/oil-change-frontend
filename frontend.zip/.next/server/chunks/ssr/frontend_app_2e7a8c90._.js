module.exports=[13157,a=>{a.v("/_next/static/media/favicon.aab55e25.ico")},93348,a=>{"use strict";a.s(["default",()=>b]);let b={src:a.i(13157).default,width:256,height:256}}];

//# sourceMappingURL=frontend_app_2e7a8c90._.js.map