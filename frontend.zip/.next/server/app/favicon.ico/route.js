var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__2c077f9e._.js")
R.c("server/chunks/[root-of-the-server]__6fd87943._.js")
R.m(22804)
R.m(44476)
module.exports=R.m(44476).exports
