globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/ee8805d0a44ac57d.js",
      "static/chunks/2a6119f56230d144.js",
      "static/chunks/turbopack-a03d4ce9c7641c6f.js"
    ],
    "/_error": [
      "static/chunks/a6a8b147318253ee.js",
      "static/chunks/2a6119f56230d144.js",
      "static/chunks/turbopack-d94aa6689ca830c6.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/664adc71bc2617c2.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/49bd190c1f4b2223.js",
    "static/chunks/f8022cc0f5a80c9d.js",
    "static/chunks/6207991686a7da40.js",
    "static/chunks/c770d9f527720a8a.js",
    "static/chunks/4e5c27b17d22fe79.js",
    "static/chunks/turbopack-4c407e62d447c9ca.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];