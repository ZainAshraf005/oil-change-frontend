__turbopack_load_page_chunks__("/_app", [
  "static/chunks/ee8805d0a44ac57d.js",
  "static/chunks/2a6119f56230d144.js",
  "static/chunks/turbopack-a03d4ce9c7641c6f.js"
])
