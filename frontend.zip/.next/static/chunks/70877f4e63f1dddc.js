__turbopack_load_page_chunks__("/_error", [
  "static/chunks/a6a8b147318253ee.js",
  "static/chunks/2a6119f56230d144.js",
  "static/chunks/turbopack-d94aa6689ca830c6.js"
])
